from entities.certificate import Certificate, EducationLevel
from entities.common_user import CommonUser
from entities.exercise import Exercise
from entities.muscle import MuscleRegion
from entities.nutritionist import Nutritionist
from entities.personal_trainer import PersonalTrainer
from entities.product import Product
from entities.training import Training
from entities.user import User


class Main:
    def __init__(self):
        pass

    def executa(self):
        usuario_comum = CommonUser(
            "1",
            "Ana",
            25,
            "123.456.789-00",
            "1998-05-15",
            "2022-01-01",
            "ana123",
            "ana@email.com"
        )

        usuario_comum.login("ana123", "senha.1234")

        # Adicionando treinos ao usuário comum
        treino1 = Training("Treino Cardio")
        treino2 = Training("Treino de Força")

        usuario_comum.adicionar_treino(treino1)
        usuario_comum.adicionar_treino(treino2)

        # Realizando um treino
        usuario_comum.realizar_treino()

        # Iniciando análise de treino por IA
        usuario_comum.iniciar_analise_de_treino_por_ia()

        # Exibindo informações
        print(f"Nome do usuário comum: {usuario_comum.name}")
        print("Treinos do usuário comum:")
        for treino in usuario_comum.treinos:
            print(f"  - {treino.name}")

        # Criando produtos
        produto1 = Product("1", "Camiseta", 25.0)
        produto2 = Product("2", "Calça Jeans", 50.0)

        # Adicionando produtos ao carrinho do usuário comum
        usuario_comum.add_produto_ao_carrinho(produto1)
        usuario_comum.add_produto_ao_carrinho(produto2)

        # Exibindo produtos no carrinho
        print("Produtos no carrinho:")
        for produto in usuario_comum.shopping_cart.produtos:
            print(f"  - {produto.nome} - R${produto.preco:.2f}")

        # Calculando o preço total no carrinho
        total_no_carrinho = usuario_comum.calcular_preco_total_no_carrinho()
        print(f"Preço total no carrinho: R${total_no_carrinho:.2f}")

        # Calculando o frete do carrinho
        frete_do_carrinho = usuario_comum.calcular_frete_do_carrinho()
        print(f"Custo do frete: R${frete_do_carrinho:.2f}")

        # Efetuando a compra
        usuario_comum.efetuar_compra()

# Executando a classe Main
if __name__ == "__main__":
    main = Main()
    main.executa()
