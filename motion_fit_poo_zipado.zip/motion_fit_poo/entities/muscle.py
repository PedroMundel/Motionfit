from enum import Enum

class MuscleRegion(Enum):
    SUPERIOR_CORPO = "Superior do Corpo"
    INFERIOR_CORPO = "Inferior do Corpo"
    CORE = "Núcleo"

class Muscle:
    def __init__(self, name, region):
        self.name = name
        self.region = MuscleRegion(region)
