from ast import List
from entities.training import Training
from entities.user import User

class CommonUser(User):
    def __init__(self, id, name, age, cpf, birth_date, entry_date, username, email):
        super().__init__(id, name, age, cpf, birth_date, entry_date, username, email)
        self.treinos: List[Training] = []

    def adicionar_treino(self, treino):
        if self.logged_in:
            self.treinos.append(treino)
            print(f"Treino '{treino.name}' adicionado ao usuário comum {self.name}.")
        else:
            print("Faça o login primeiro.")

    def realizar_treino(self):
        if self.logged_in:
            print(f"Realizando treino para o usuário comum {self.name}...")
            # Lógica para realizar um treino
        else:
            print("Faça o login primeiro.")

    def iniciar_analise_de_treino_por_ia(self):
        if self.logged_in:
            print(f"Iniciando análise de treino por IA para o usuário comum {self.name}...")
            # Lógica para iniciar a análise de treino por IA
        else:
            print("Faça o login primeiro.")
