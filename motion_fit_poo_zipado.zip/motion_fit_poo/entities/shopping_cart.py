# shopping_cart.py
class ShoppingCart:
    def __init__(self):
        self.preco_total = 0.0
        self.custo_do_frete = 0.0
        self.produtos = []

    def add_produto(self, produto):
        self.produtos.append(produto)
        print(f"Produto '{produto.nome}' adicionado ao carrinho.")

    def remover_produto(self, produto):
        if produto in self.produtos:
            self.produtos.remove(produto)
            print(f"Produto '{produto.nome}' removido do carrinho.")
        else:
            print(f"Produto '{produto.nome}' não encontrado no carrinho.")

    def calcular_preco_total(self):
        self.preco_total = sum(produto.preco for produto in self.produtos)
        return self.preco_total

    def calcular_frete(self):
        # Lógica para calcular o custo do frete
        # Aqui, uma simplificação: 10% do preço total
        self.custo_do_frete = 0.1 * self.preco_total
        return self.custo_do_frete

    def efetuar_compra(self):
        total_com_frete = self.preco_total + self.custo_do_frete
        print(f"Compra efetuada! Total a pagar: R${total_com_frete:.2f}")
        # Lógica adicional, como atualizar o estoque, processar pagamento, etc.
        return True
