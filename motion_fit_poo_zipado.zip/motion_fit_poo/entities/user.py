from datetime import datetime
from entities.shopping_cart import ShoppingCart

class User:
    def __init__(self, id, name, age, cpf, birth_date, entry_date, username, email):
        self.id = id
        self.name = name
        self.age = age
        self.cpf = cpf
        self.birth_date = datetime.strptime(birth_date, "%Y-%m-%d")
        self.entry_date = datetime.strptime(entry_date, "%Y-%m-%d")
        self.username = username
        self.email = email
        self.logged_in = False
        self.shopping_cart = ShoppingCart() # Inicializa um carrinho de compras

    def add_produto_ao_carrinho(self, produto):
        if(self.logged_in):
            self.shopping_cart.add_produto(produto)
        else :
            print("Usuário precisa estar logado")

    def remover_produto_do_carrinho(self, produto):        
        if(self.logged_in):
            self.shopping_cart.remover_produto(produto)
        else :
            print("Usuário precisa estar logado")

    def calcular_preco_total_no_carrinho(self):
        if(self.logged_in):
            return self.shopping_cart.calcular_preco_total()
        else :
            print("Usuário precisa estar logado")

    def calcular_frete_do_carrinho(self):
        if(self.logged_in):
            return self.shopping_cart.calcular_frete()
        else :
            print("Usuário precisa estar logado")

    def efetuar_compra(self):
        if(self.logged_in):
            return self.shopping_cart.efetuar_compra()
        else :
            print("Usuário precisa estar logado")

    def login(self, user, password):
        if user == self.username and password == "senha.1234":
            self.logged_in = True
            print("Login bem-sucedido.")
        else:
            print("Credenciais inválidas. Falha no login.")

    def logout(self):
        self.logged_in = False
        print("Logout bem-sucedido.")
