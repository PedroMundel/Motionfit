class Product:
    def __init__(self, id, nome, preco):
        self.id = id
        self.nome = nome
        self.preco = preco